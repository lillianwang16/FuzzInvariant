// This test does no allocations, to make sure that case is handled ok (eg.
// no div-by-zero errors).

int main(void)
{
   return 0;
}
