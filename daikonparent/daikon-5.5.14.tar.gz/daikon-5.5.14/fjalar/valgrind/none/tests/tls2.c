#include <config.h>

#ifdef HAVE_TLS
__thread int static_extern;
#endif
