#include <pthread.h>

int main()
{
	pthread_exit(0);
}
